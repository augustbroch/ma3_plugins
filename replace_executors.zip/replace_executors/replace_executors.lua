-- LICENSE: See license.txt

--[[
-- Get the LUA component handle for our plugin. We store our config in here
-- select(4,...) gives us lua component handle (child of plugin handle)
--]]
local luacomponent = select(4, ...)

-- split: Split string using separator. Default to whitespace as separator of none are given
local function split(str, sep)
    if sep == nil then
        sep = "%s"
    end
    local t = {}
    for word in string.gmatch(str, "([^"..sep.."]+)") do
        table.insert(t, word)
    end

    return t
end

local function config(args)
    local executors = {}
    executors[1] = {}
    executors[2] = {}

    if not pcall(function ()
        executors[1].page = tonumber(split(args[2], ".")[1])
        executors[1].id = tonumber(split(args[2], ".")[2])
        executors[2].page = tonumber(split(args[3], ".")[1])
        executors[2].id = tonumber(split(args[3], ".")[2])

        -- Assert that there are no nil values in executors
        for _, executor in ipairs(executors) do
            assert(executor.page)
            assert(executor.id)
        end
    end) then
        Printf("config requires the following arguments to be valid:")
        Printf('Plugin "replace_executors" "config {page}.{exec-id} {page}.{replacement-exec-id}"')
        return -1
    end

    -- Store the config as a note inside our lua component
    local config = executors[1].page .. "." .. executors[1].id .. " " .. executors[2].page .. "." .. executors[2].id
    luacomponent.Note = config

    Confirm("Warning", "Warning! This plugin requires a free spot to the right of the replacement executor. It needs this as a free temporary storage when replacing the executors", nil, false)
    Printf("Successfully updated config for executors")

    return 0
end

-- replace: Replace executor by executor-replacement stored in config
local function replace()
    -- Fetch executor pages and ids from config
    local config = {}
    local executors = {}
    executors[1] = {}
    executors[2] = {}
    if not pcall(function ()
        config = split(luacomponent.Note)
        for i = 1, #executors do
            executors[i].page = tonumber(split(config[i], ".")[1])
            assert(executors[i].page)
            executors[i].id = tonumber(split(config[i], ".")[2])
            assert(executors[i].id)
        end
    end) then
        ErrPrintf('Error: Error when parsing config. Have you ran "config {page}.{executor-id} {page}.{replacement-executor-id}"?')
        return -1
    end


    -- Get handle of first executor and sequence (first->to be replaced, second->replacing current)
    -- API used: DataPool().Pages[page-id][Executor-id - 100]
    -- Need to include - 100 for some reason. Is ex208=id108?
    local first_executor = DataPool().Pages[executors[1].page][executors[1].id-100]
    local first_seq = first_executor:GetAssignedObj()
    
    -- Get handle of other executor
    local second_executor = DataPool().Pages[executors[2].page][executors[2].id-100]
    
    -- Used later when assigning value to a fader
    local fader_value = 0
    
    -- See if current sequence is running
    if first_seq:HasActivePlayback() then
        -- Take value from current FaderMaster and give it to other FaderMaster
        fader_value = first_executor:GetFader{token='FaderMaster'}
        second_executor:SetFader{token='FaderMaster',value=fader_value}
        
        -- Start other executor
        Cmd("On page " .. executors[2].page .. "." .. executors[2].id)
        
        -- Stop current executor
        Cmd("Off page " .. executors[1].page .. "." .. executors[1].id)
        
        -- Replace current exec with other from page 2
        -- DANGER: THIS REQUIRES A FREE SPOT TO THE RIGHT OF THE SECOND EXECUTOR!
        Cmd("Move Page " .. executors[2].page .. "." .. executors[2].id .. " at Page " .. executors[2].page .. "." .. executors[2].id + 1)
        Cmd("Move Page " .. executors[1].page .. "." .. executors[1].id .. " at Page " .. executors[2].page .. "." .. executors[2].id)
        Cmd("Move Page " .. executors[2].page .. "." .. executors[2].id + 1 .. " at Page " .. executors[1].page .. "." .. executors[1].id)
        
    else
        -- Set FaderMaster on other executor to 0
        second_executor:SetFader{token='FaderMaster',value=0}
        
        -- Replace current exec with other from page 2
        -- DANGER: THIS REQUIRES A FREE SPOT TO THE RIGHT OF THE SECOND EXECUTOR!
        Cmd("Move Page " .. executors[2].page .. "." .. executors[2].id .. " at Page " .. executors[2].page .. "." .. executors[2].id + 1)
        Cmd("Move Page " .. executors[1].page .. "." .. executors[1].id .. " at Page " .. executors[2].page .. "." .. executors[2].id)
        Cmd("Move Page " .. executors[2].page .. "." .. executors[2].id + 1 .. " at Page " .. executors[1].page .. "." .. executors[1].id)
    end

    return 0
end

local function how_to_use()
    Printf('Use plugin with "replace" or "config {page}.{exec-id} {page}.{exec-replacement-id}"')
end

--[[
    replace_executors.lua: Plugin that swaps out executor for another
    It sets the other executor to the first executors state.
    Then it turns of the first one, and swap their position.
    Useful for swapping sin and pwn effect executor in a seemless manner

    Configure it with Plugin "replace_executors" "config {page}.{exec-id} {page}.{exec-replacement-id}".
    Use it and replace executors with Plugin "dim_replace" "replace"
--]]
local function main(screen, args)
    if not args then
        if replace() == -1 then
            return
        end
        return
    end
    args = split(args)
    if args[1] == "config" then
        if config(args) == -1 then
            return
        end
    else
        ErrPrintf("Error: Received unexpected argument")
        how_to_use()
        return
    end
end

return main
