--[[
Copyright © 2025 August Broch

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
--]]

--[[
-- Get the LUA component handle for our plugin. We store our config in here
-- select(4,...) gives us lua component handle (child of plugin handle)
--]]
local luacomponent = select(4, ...)

local function split(str, sep)
    if sep == nil then
        sep = "%s"
    end
    local t = {}
    for word in string.gmatch(str, "([^"..sep.."]+)") do
        table.insert(t, word)
    end
    return t
end

local function how_to_use()
    Confirm("How to use", "See video on how to use: https://youtu.be/OLBLaTGxRuw", nil, false)
end

-- get_selections(): Read recipe-lines from first cue in given executor,
-- the lines should contain a selection. Collect the selections in a table
-- and return that table
local function get_selections(exec_id)
    local exec = ObjectList("Page " .. exec_id)[1]
    if not exec then
        ErrPrintf("Error: Could not find executor %s", exec_id)
        return nil
    end
    -- Get sequence-object from executor
    local seq = exec.object
    if not seq then
        ErrPrintf("Error: Could not find executor-object (sequence)")
        return nil
    end
    local cuepart = seq[3][1]
    if not cuepart[1] then
        ErrPrintf("Error: Could not find recipe-line(s) in cuepart. Expected first cue part 0 to contain recipe-line(s) with selection of fixtures that should be used in the executor (see How to use)")
        return nil
    end
    local selections = {} -- Table containing fixture-groups stored as selections in recipes from first cue part 0
    for _, recipe in ipairs(cuepart) do
        local selection = recipe.selection
        if not selection then
            ErrPrintf("Found recipe-line, but with no selection in first cue.. Stopping program")
            return nil
        end
        table.insert(selections, selection)
    end
    return selections
end

-- make_cue_recipes(): Make recipes for each cue, and set fixture-groups
local function make_cue_recipes(exec_id, fixture_groups, quickcall_data)
    local exec = ObjectList("Page " .. exec_id)[1]
    if not exec then
        ErrPrintf("Error: Could not get executor")
        return nil
    end
    local seq = exec.object
    if not seq then
        ErrPrintf("Error: Could not get object from executor (sequence)")
        return nil
    end
    for cue_no = 4, #seq do -- cue-no = offcue+cue-zero+fixturecue+1
        local cuepart = seq[cue_no][1]
        if not cuepart then
            ErrPrintf("Error: Could not open cuepart")
            return nil
        end
        -- Create and fill recipe-line(s)
        for i, fixture_group in ipairs(fixture_groups) do
            cuepart:Append()
            cuepart[i].selection = fixture_group
            -- Get MA cue_no (!= cue_no) The cue-number corresponds with my quickcall_id
            local ma_cue_no = seq[cue_no].index
            -- Get preset data using ma_cue_no (aka quickcall_id)
            local preset_no = quickcall_data[ma_cue_no].preset_id
            if not preset_no then
                ErrPrintf("Error: Could not get preset-number for cue")
                return nil
            end
            -- Get preset object
            local preset = ObjectList("Preset ".. preset_no)[1]
            if not preset then
                ErrPrintf("Error: Could not find preset " .. preset_no)
                return nil
            end
            -- Set recipe-value to preset
            cuepart[i].values = preset
        end
    end
    return 0
end

--[[ update_macro():
    - Remove possible existing lines from macro
    - Write a line for each executor, so the executors trigs cue corresponding to current quickcall_id
    - The command is written so that is uses a method of this plugin, using a custom timing (quickcall time). It
        either follows executor time (signal -1), or some other custom time (that can be longer than 10 seconds)
--]]
local function update_macro(quickcall_data_row, executors)
    local undo = CreateUndo("quickcall: Overwrite macros")
    -- Macro-object is stored in quickcall_data
    local macro = quickcall_data_row.macro
    -- Delete existing macro lines
    local macro_id = macro.index
    Cmd("Delete macro ".. macro_id .. ".1 thru", undo)

    -- Make macro-lines for each executor
    for i = 1, #executors do
        -- Store macro line
        macro:Append()
        -- Set macroline command
        macro[i]:Set("Command", 'Plugin "quickcall" "call ' .. quickcall_data_row.quickcall_id .. ' ' .. executors[i] .. '"')
    end

    CloseUndo(undo)
    return 0
end

local function setup()
    -- Get macro ids
    local inputs = {
        {name = "First macro", whiteFilter = "0123456789"},
        {name = "Last macro", whiteFilter = "0123456789"}
    }
    local prompt = MessageBox(
        {
            title = "Setup",
            message = "Type in number of first and last macro you want to use as quickcall",
            inputs = inputs,
            commands = {{value = 1, name = "Ok"}, {value = 0, name = "Cancel"}},
        }
    )
    if prompt.result == 0 then
        ErrPrintf("Input aborted by user")
        return nil
    end

    if prompt.inputs["First macro"] == "" or prompt.inputs["Last macro"] == "" then
        ErrPrintf("Error: Received empty input, expected macro-ids")
        return nil
    end
    local first_macro_id = tonumber(prompt.inputs["First macro"])
    local last_macro_id = tonumber(prompt.inputs["Last macro"])

    if last_macro_id - first_macro_id < 0 then
        ErrPrintf("Error: Last macro number must be greater than first macro")
        return nil
    end
    
    local macros = ObjectList("macro " .. first_macro_id .. " thru " .. last_macro_id)
    if macros[1] == nil then
        ErrPrintf("Error: Could not find any matching macros")
        return nil
    end

    -- Ojbect holding macros, corresponding presets, executors and corresponding fixtures that will be set up for quickcall
    local quickcall_data = {}

    -- Get corresponding presets
    for _, v in ipairs(macros) do
        local inputs = {{name = "Preset", whiteFilter = "0123456789."}}
        local prompt = MessageBox(
            {
                title = "Corresponding preset, Macro " .. v.index,
                message = "What preset should quickcall-macro " .. v.index .. " " .. v.name .. " call?",
                inputs = inputs,
                commands = {{value = 1, name = "Ok"}, {value = 0, name = "Cancel"}}
            }
        )
        if prompt.result == 0 then
            ErrPrintf("Input aborted by user")
            return nil
        end

        local preset_id = tostring(prompt.inputs["Preset"])

        -- Check that specified preset follows correct syntax: [number].[number]
        if not string.match(preset_id, "^%d+%.%d+$") then
            ErrPrintf("Error: Invalid preset syntax. Expected [number].[number]")
            return nil
        end

        -- Check if the preset exists
        local preset = ObjectList("Preset " .. preset_id)
        if preset[1] == nil then
            ErrPrintf("Error: Preset specified does not exist")
            return nil
        end

        -- "Pretty" id that will be used for enumeration in cue-names e.g.
        local quickcall_id = tonumber(v.index) - first_macro_id + 1

        quickcall_data[quickcall_id] = {
            quickcall_id = quickcall_id,
            name = quickcall_id .. " " .. v.name,
            preset_id = preset_id,
            macro = v
        }
    end

    -- Create table with sorted key-array for quickcall_data
    local keys = {}
    for k, v in pairs(quickcall_data) do
        table.insert(keys, k)
    end
    table.sort(keys)
    -- Insert sorted keys table as 0-th element of array. This will not be read with ipairs, so its safe here :)
    quickcall_data[0] = keys

    -- Get executors we want to store to
    local inputs = {{name = "Executors", whiteFilter = "0123456789. "}}
    local prompt = MessageBox(
        {
            title = "Assign executors to quickcall",
            message = "Assign executors to use with quickcall. Syntax [page].[executor] [page].[executor] [page].[executor]...",
            inputs = inputs,
            commands = {{value = 1, name = "Ok"}, {value = 0, name = "Cancel"}}
        }
    )
    if prompt.result == 0 then
        ErrPrintf("Input aborted by user")
        return nil
    end

    -- Test for valid executor syntax ([page].[executor] [page].[executor]...), and test that the specified executors exists
    if prompt.inputs["Executors"] == "" then
        ErrPrintf("Error: No executors specified, received empty string")
        return nil
    end
    local executors = split(prompt.inputs["Executors"])
    for _, v in ipairs(executors) do
        -- Syntax-test
        if not string.match(v, "^%d+%.%d+$") then
            ErrPrintf("Error: Invalid executor syntax. Expected [page].[executor]")
            return nil
        end
        -- See if executor exists
        if ObjectList("Page " .. v)[1] == nil then
            ErrPrintf("Error: Executor " .. v .. " does not exist")
            return nil
        end
    end

    -- Create undo handle
    local undo = CreateUndo("Quickcall: Overwrite executors")

    for _, exec_id in ipairs(executors) do
        -- Inside every executor, first cue should contain recipe-line(s) with selection set
        -- to a fixture-group. We collect these group(s) to make recipes in cues with them
        local fixture_groups = get_selections(exec_id)
        if not fixture_groups then
            return nil
        end

        -- We now have all data we need to start!
        -- Start by clearing all cues in list from 1 (first cue containing selections should be 0.1)
        Cmd("Delete Page " .. exec_id .. " cue 1 thru", undo)


        -- Store new cues with proper naming and cue-numbers (key/quickcall-id)
        for _, key in ipairs(quickcall_data[0]) do
            Cmd("Store Page " .. exec_id .. " cue " .. key, undo)
            Cmd("Label Page " .. exec_id .. " cue " .. key .. ' "' .. quickcall_data[key].name .. '"', undo)
        end
        -- Make cue recipes for all cues in executor
        if make_cue_recipes(exec_id, fixture_groups, quickcall_data) == nil then
            return nil
        end
    end

    CloseUndo(undo)

    -- Update macros, so they point to all our chosen executors
    -- Make the macros call this plugin to get custom quickcall-timing (can be greater than executor-id)
    for k, v in ipairs(quickcall_data[0]) do
        if update_macro(quickcall_data[v], executors) == nil then
            return nil
        end
    end

    return 0
end

local function quickcall(page_id, qc_id)
    -- Possible case: Empty note first time. If the note is empty, we set it to -1
    -- to signal use executor time
    if luacomponent.Note == "" then
        luacomponent.Note = "-1"
    end

    if luacomponent.Note == "-1" then
        -- Command will use executor time if it is turned on
        Cmd("Goto Page " .. page_id .. " Cue " .. qc_id)
    else
        if not string.match(luacomponent.Note, "^%d*%.?%d+$") then
            ErrPrintf("Error: Invalid note in quickcall lua component (syntax error)")
            return nil
        end

        Cmd("Goto Page " .. page_id .. " Cue " .. qc_id .. " Fade " .. luacomponent.Note)
    end

    return 0
end
local function update_qctime(new_time)
    if new_time == "-1" then
        -- Use executor time
        luacomponent.Note = "-1"
    else
        -- Use new_time as quickcall time
        luacomponent.Note = new_time
    end
end

local function main(screen, args)
    -- If we get args, that means the user (or more likely auto-created macro) wants
    -- to quickcall a preset, or update the quickcall_timing
    -- Otherwise, we open the setup popup to set up quickcall
    if args then
        -- ===== VALIDATE SUPPLIED ARGS =====
        local args_t = split(args)
            if args_t[1] == "call" then
                if #args_t < 3 then
                    ErrPrintf("Error: quickcall_timing expects at least 3 arguments ")
                    return
                end
                if not string.match(args_t[2], "^%d+$") then
                    ErrPrintf("Error: Expected valid quickcall_id as second argument. See how to use")
                    return
                end
                for i = 3, #args_t do
                    if not string.match(args_t[i], "^%d+%.%d+$") then -- Test syntax
                        ErrPrintf("Error: Expected [page].[executor] [page].[executor]... See How to use")
                        return
                    end
                    -- Make sure executors exists
                    local exec = ObjectList("Page " .. args_t[i])[1]
                    if not exec then
                        ErrPrintf("Error: Executor " .. args_t[i] .. " does not exist")
                        return
                    end

                    -- Call executor at quickcall_id with quickcall_timing
                    if quickcall(args_t[i], args_t[2]) == nil then
                        return
                    end
                end
            elseif args_t[1] == "set_time" then
                if #args_t ~= 2 then
                    ErrPrintf("Error: expects 2 arguments to set_time")
                    return
                end
                if args_t[2] == "exec_time" then
                    -- Update quickcall time. -1 signals to use executor time as qctime
                    update_qctime("-1")
                    return
                end
                -- Only other expected argument is a digit for setting the quickcall_time in seconds
                if not string.match(args_t[2], "^%d*%.?%d+$") then
                    ErrPrintf("Invalid argument. Expected positive digit (time in seconds)")
                    return
                end

                update_qctime(args_t[2])
            elseif args_t[1] == "set_time_from_var" then
                local var = GetVar(UserVars(), "quickcall_time")
                if not var then
                    ErrPrintf("Error: Could not find quickcall_time variable")
                    return
                end
                var = tostring(var)
                if var == "-1" then
                    update_qctime("-1")
                    return
                end
                if not string.match(var, "^%d*%.?%d+$") then
                    ErrPrintf("Error: Invalid syntax in user variable quickcall_time: " .. var)
                    return
                end
                update_qctime(var)
            else
                ErrPrintf("Error: Expected call, set_time or set_time_from_var as first word in argument. See How to use")
                return
            end

        return
    end

    -- If no supplied args, run setup dialogs
    local prompt = MessageBox(
		{
			title = "QuickCall",
			message = "Setup executors and custom-timing macros for quickcall",
			commands = {{value = 1, name = "Setup"}, {value = 2, name = "How to use"}},
			autoCloseOnInput = true
		})
        if prompt.result == 1 then
            if setup() == nil then
                return
            end
        elseif prompt.result == 2 then
            how_to_use()
            return
        end
end

return main