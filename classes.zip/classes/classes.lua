local function main(screen, args)
    local fixtures = ObjectList("Fixture 1 thru")

    local class_name = TextInput("Find fixtures from class", "Type in class-name, e.g. 1 'truss' has the name truss")

    local matching_fixtures = {}

    for _, fixture in ipairs(fixtures) do
        if fixture.Class == nil then goto continue end

        if fixture.Class.Name == class_name then
            table.insert(matching_fixtures, fixture.Fid)
        end
        ::continue::
    end

    local undo = CreateUndo("classes")
    for _, fid in ipairs(matching_fixtures) do
        Cmd("Fixture " .. fid, undo)
    end
    CloseUndo(undo)
end

return main